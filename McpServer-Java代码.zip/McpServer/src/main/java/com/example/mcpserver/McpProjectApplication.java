package com.example.mcpserver;

import org.springframework.ai.tool.ToolCallbackProvider;
import org.springframework.ai.tool.method.MethodToolCallbackProvider;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class McpProjectApplication {

    public static void main(String[] args) {
        SpringApplication.run(McpProjectApplication.class, args);
    }


    /**
     * MethodToolCallbackProvider 是一个 Spring AI 工具回调提供程序，用于将方法调用转换为工具回调。
     * 它可以将任何包含 @Tool 注解的方法转换为工具回调，从而使这些方法可以被 Spring AI 框架调用。
     * 这使得在 Spring Boot 应用程序中使用 Spring AI 变得更加容易。
     * 例如，在这个应用程序中，我们使用 MethodToolCallbackProvider 将 WeatherService 中的方法转换为工具回调。
     * 这样，我们就可以在 Spring AI 中使用这些方法来获取天气信息。
     * 具体来说，我们使用 MethodToolCallbackProvider.builder().toolObjects(weatherService).build()
     * 来创建一个 MethodToolCallbackProvider 对象，
     * 并将 WeatherService 作为工具对象传递给它。这样，我们就可以在 Spring AI 中使用 WeatherService 中的方法来获取天气信息。
     * 例如，我们可以使用 @Tool 注解来标记 WeatherService 中的方法，然后在 Spring AI 中使用这些方法来获取天气信息。
     * @param weatherService
     * @return
     */
    @Bean
    public ToolCallbackProvider weatherTools(WeatherService weatherService) {
        return MethodToolCallbackProvider.builder().toolObjects(weatherService).build();
    }

}
